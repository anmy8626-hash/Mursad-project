#include <WiFi.h>
#include <Wire.h>
#include <Adafruit_GFX.h>
#include <Adafruit_SSD1306.h>
#include <Adafruit_BMP280.h>
#include <OneWire.h>
#include <DallasTemperature.h>
#include <Stepper.h>

// 1. إعدادات شاشة OLED (0.91 بوصة) والحساسات
Adafruit_SSD1306 display(128, 32, &Wire, -1);
Adafruit_BMP280 bmp;
OneWire oneWire(4);
DallasTemperature sensors(&oneWire);

// 2. إعدادات المحرك الخطوي (28BYJ-48) ودبابيس الريليه ثنائي القناة
Stepper myStepper(2048, 19, 25, 23, 26); // IN1=19, IN3=25, IN2=23, IN4=26
const int RELAY_LAMP_PIN = 5;   // القناة K1 للمبة (IN1)
const int RELAY_MOTOR_PIN = 18; // القناة K2 للمحرك (IN2)

// 3. إعدادات الشبكة وخادم Modbus TCP
WiFiServer modbusServer(502);

// السجلات المشتركة مع Node-RED وكود البايثون:
// [0:V, 1:I, 2:T, 3:PF, 4:P_atm, 5:Power, 6:Lamp, 7:Motor]
uint16_t Hreg[10] = {2200, 250, 375, 850, 10132, 4675, 1, 1, 0, 0};
bool systemIsolated = false;

void setup() {
  Serial.begin(115200);
  Wire.begin(21, 22); // SDA = 21, SCL = 22

// تهيئة الريليه (تشغيل اللمبة والمحرك معاً عند البدء)
  pinMode(RELAY_LAMP_PIN, OUTPUT);
  pinMode(RELAY_MOTOR_PIN, OUTPUT);
  digitalWrite(RELAY_LAMP_PIN, HIGH);
  digitalWrite(RELAY_MOTOR_PIN, HIGH);
  
  myStepper.setSpeed(12); // سرعة دوران المحرك

  // تشغيل شاشة OLED
  display.begin(SSD1306_SWITCHCAPVCC, 0x3C);
  display.clearDisplay();
  display.setTextSize(1);
  display.setTextColor(WHITE);

  // تشغيل الحساسات
  bmp.begin(0x76);
  sensors.begin();
  sensors.setWaitForConversion(false);
  sensors.requestTemperatures();

  // بث شبكة واي فاي مستقلة من شريحة ESP32
  WiFi.softAP("Mursad_Shield", "12345678");
  modbusServer.begin();

  display.setCursor(0, 0);
  display.println("WiFi: Mursad_Shield");
  display.println("Pass: 12345678");
  display.println("IP: 192.168.4.1");
  display.display();
  delay(3000);
}

void loop() {
  handleModbusTCP(); // الاستماع لأوامر الشبكة ولوحة Node-RED
  if (systemIsolated) return;

  // 1. قراءة الحساسات الحية
  static unsigned long lastTempReq = 0;
  static float realTemp = 37.5;
  if (millis() - lastTempReq > 1000) {
    float t = sensors.getTempCByIndex(0);
    if (t > -50 && t < 150) realTemp = t;
    sensors.requestTemperatures();
    lastTempReq = millis();
  }

  float realPressure = bmp.readPressure() / 100.0F;
  if (realPressure < 800 || realPressure > 1200) realPressure = 1013.2;

  // 2. التحكم في اللمبة والمحرك بناءً على السجلات
  bool lampOn = (Hreg[6] == 1);
  bool motorOn = (Hreg[7] == 1);

  digitalWrite(RELAY_LAMP_PIN, lampOn ? HIGH : LOW);
  digitalWrite(RELAY_MOTOR_PIN, motorOn ? HIGH : LOW);

  // 3. الحسابات الفيزيائية للتوأم الرقمي
  float voltage = 220.0;
  float current = (lampOn ? 0.40 : 0.0) + (motorOn ? 2.10 : 0.0);
  if (current == 0) current = 0.01;
  float pf = motorOn ? 0.85 : 0.98;
  float calculatedPower = voltage * current * pf;

  static uint16_t lastKnownPower = 4675;
  float reportedPower = Hreg[5] / 10.0;

  // تحديث القدرة تلقائياً في الوضع الطبيعي ما لم يتم تزويرها عبر الشبكة
  if (Hreg[5] == lastKnownPower) {
    reportedPower = calculatedPower;
    lastKnownPower = (uint16_t)(calculatedPower * 10);
    Hreg[5] = lastKnownPower;
  }

  // تحديث السجلات لإرسالها إلى لوحة Node-RED
  Hreg[0] = (uint16_t)(voltage * 10);
  Hreg[1] = (uint16_t)(current * 100);
  Hreg[2] = (uint16_t)(realTemp * 10);
  Hreg[3] = (uint16_t)(pf * 1000);
  Hreg[4] = (uint16_t)(realPressure * 10);

  // 4. قواعد العزل الفيزيائي الفوري (CR-2 و الحرارة)
  if (calculatedPower > 5.0 && abs(reportedPower - calculatedPower) / calculatedPower > 0.15) {
    triggerIsolation("CR-2: Power Spoof!");
    return;
  }
  if (realTemp > 45.0) {
    triggerIsolation("TEMP HIGH > 45C!");
    return;
  }

  // 5. تدوير المحرك باستمرار طالما هو في وضع التشغيل
  if (motorOn) {
    myStepper.step(40);
  }

// 6. تحديث شاشة OLED بالقراءات الحية
  display.clearDisplay();
  display.setCursor(0, 0);
  display.printf("STATUS: ALL ACTIVE\n");
  display.printf("T:%.1fC  P:%.0fhPa\n", realTemp, realPressure);
  display.printf("Pwr:%.1fW  Z:%.0f Ohm", reportedPower, voltage / current);
  display.display();
}

void handleModbusTCP() {
  WiFiClient client = modbusServer.available();
  if (client) {
    unsigned long timeout = millis() + 200;
    while (client.connected() && client.available() < 12 && millis() < timeout) {
      delay(1);
    }
    if (client.available() >= 12) {
      uint8_t req[12];
      int received = client.read(req, sizeof(req));

if (received != sizeof(req) ||
    req[2] != 0 || req[3] != 0 ||
    req[4] != 0 || req[5] != 6) {
  client.stop();
  return;
}
      uint8_t func = req[7];
      uint16_t addr = (req[8] << 8) | req[9];

      // استجابة لقراءة السجلات (Node-RED)
      if (func == 0x03) {
        uint16_t count = (req[10] << 8) | req[11];
        if (addr >= 10 || count == 0 || count > 10 || count > (10 - addr)) {
  uint8_t error = (count == 0 || count > 10) ? 0x03 : 0x02;
  uint8_t response[9] = {
    req[0], req[1], 0, 0, 0, 3,
    req[6], 0x83, error
  };
  client.write(response, 9);
  client.stop();
  return;
}
        uint8_t resp[30] = {req[0], req[1], 0, 0, 0, (uint8_t)(3 + count * 2), req[6], 0x03, (uint8_t)(count * 2)};
        for (int i = 0; i < count; i++) {
          uint16_t val = (addr + i < 10) ? Hreg[addr + i] : 0;
          resp[9 + i * 2] = val >> 8;
          resp[10 + i * 2] = val & 0xFF;
        }
        client.write(resp, 9 + count * 2);
      }
      // استجابة لكتابة الأوامر أو الهجوم (Python)
     else if (func == 0x06) {
  uint16_t value = (req[10] << 8) | req[11];
  uint8_t error = 0;

  if (addr != 6 && addr != 7) {
    error = 0x02;
  }
  else if (value > 1) {
    error = 0x03;
  }
  else if (systemIsolated && value == 1) {
    error = 0x04;
  }

  if (error != 0) {
    uint8_t response[9] = {
      req[0], req[1], 0, 0, 0, 3,
      req[6], 0x86, error
    };
    client.write(response, 9);
  }
  else {
    Hreg[addr] = value;
    client.write(req, 12);
  }
}
else {
  uint8_t response[9] = {
    req[0], req[1], 0, 0, 0, 3,
    req[6], (uint8_t)(func | 0x80), 0x01
  };
  client.write(response, 9);
}
    }
    client.stop();
  }
}

void triggerIsolation(String reason) {
  systemIsolated = true;
  Hreg[6] = 0;
  Hreg[7] = 0;
  // عزل مادي مزدوج: إطفاء اللمبة وفصل المحرك فوراً
  digitalWrite(RELAY_LAMP_PIN, LOW);
  digitalWrite(RELAY_MOTOR_PIN, LOW);

  display.clearDisplay();
  display.setCursor(0, 0);
  display.println("!! CRITICAL ATTACK !!");
  display.println(reason);
  display.println("SYSTEM ISOLATED");
  display.display();
}


