from pymodbus.client import ModbusTcpClient

client = ModbusTcpClient("127.0.0.1", port=5020)

if not client.connect():
    raise SystemExit("Connection failed")

result = client.read_holding_registers(
    address=0,
    count=3,
    device_id=1
)

if result.isError():
    print("Modbus error:", result)
else:
    print("Voltage:", result.registers[0])
    print("Current:", result.registers[1])
    print("Temperature:", result.registers[2])

client.close()