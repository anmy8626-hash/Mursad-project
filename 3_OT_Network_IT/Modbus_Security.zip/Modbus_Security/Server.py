from pymodbus.server import StartTcpServer
from pymodbus.simulator import SimDevice, SimData, DataType

values = [220, 5, 30] + [0] * 7

device = SimDevice(
    1,
    SimData(
        address=0,
        values=values,
        datatype=DataType.REGISTERS
    )
)

print("Modbus Server starting on 127.0.0.1:5020")

StartTcpServer(
    device,
    address=("127.0.0.1", 5020)
)